# !bin/bash/

make clean
make
make matrix
rm log.txt
./bin/matrix 1
